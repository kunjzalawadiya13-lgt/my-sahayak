package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.lifecycle.viewmodel.initializer
import com.example.data.repository.ChatRepository
import com.example.ui.components.SignInScreen
import com.example.ui.screens.MainChatScreen
import com.example.ui.theme.SahayakDarkBg
import com.example.ui.theme.SahayakTheme
import com.example.ui.viewmodel.ChatViewModel
import com.example.util.configureAppCheck
import com.example.voice.SpeechManager
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // STEP 1: Mandatory App Check configuration with launch intent before any UI or Firebase operations
        configureAppCheck(this, intent)

        enableEdgeToEdge()

        setContent {
            SahayakTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = SahayakDarkBg
                ) {
                    AppNavigation(
                        databaseId = getString(R.string.firestore_database_id)
                    )
                }
            }
        }
    }
}

private fun FirebaseAuth.authStateFlow(): Flow<FirebaseUser?> = callbackFlow {
    val listener = FirebaseAuth.AuthStateListener { auth ->
        trySend(auth.currentUser)
    }
    addAuthStateListener(listener)
    awaitClose { removeAuthStateListener(listener) }
}

@Composable
fun AppNavigation(
    databaseId: String,
    auth: FirebaseAuth = Firebase.auth
) {
    val currentUser by auth.authStateFlow().collectAsStateWithLifecycle(initialValue = auth.currentUser)
    val user = currentUser

    if (user == null) {
        // Unauthenticated session: Render sign-in UI only
        SignInScreen()
    } else {
        // Authenticated session: Pass authenticated uid to feature screens
        val currentUserId = user.uid
        val viewModel: ChatViewModel = viewModel(
            key = currentUserId,
            factory = viewModelFactory {
                initializer {
                    val app = checkNotNull(this[APPLICATION_KEY]) {
                        "APPLICATION_KEY missing from CreationExtras"
                    }
                    val db = FirebaseFirestore.getInstance(databaseId)
                    val repository = ChatRepository(db)
                    val speechManager = SpeechManager(app.applicationContext)
                    ChatViewModel(repository, speechManager, currentUserId)
                }
            }
        )

        MainChatScreen(viewModel = viewModel)
    }
}
