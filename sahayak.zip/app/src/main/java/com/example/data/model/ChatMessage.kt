package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class ChatMessage(
    @DocumentId
    val id: String = "",
    val conversationId: String = "",
    val userId: String = "",
    val sender: String = "user", // "user", "model", or "system"
    val text: String = "",
    val imageUrl: String? = null,
    val thought: String? = null,
    @ServerTimestamp
    val createdAt: Timestamp? = null
)
