package com.example.data.repository

import android.util.Log
import com.example.data.model.ChatMessage
import com.example.data.model.Conversation
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

private const val TAG = "ChatRepository"

class ChatRepository(private val db: FirebaseFirestore) {

    /**
     * Observes real-time list of conversations belonging to the user.
     */
    fun observeConversations(userId: String): Flow<List<Conversation>> {
        return db.collection("conversations")
            .whereEqualTo("userId", userId)
            .snapshots()
            .map { snapshot ->
                snapshot.documents.mapNotNull { doc ->
                    doc.toObject(
                        Conversation::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }.sortedByDescending { it.updatedAt ?: it.createdAt ?: Timestamp(0, 0) }
            }
    }

    /**
     * Observes real-time messages for a specific conversation.
     */
    fun observeMessages(userId: String, conversationId: String): Flow<List<ChatMessage>> {
        return db.collection("messages")
            .whereEqualTo("userId", userId)
            .whereEqualTo("conversationId", conversationId)
            .snapshots()
            .map { snapshot ->
                snapshot.documents.mapNotNull { doc ->
                    doc.toObject(
                        ChatMessage::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }.sortedBy { it.createdAt ?: Timestamp(0, 0) }
            }
    }

    /**
     * Creates a new conversation document in Firestore.
     */
    suspend fun createConversation(userId: String, title: String, model: String): String {
        val docRef = db.collection("conversations").document()
        val data = mapOf(
            "id" to docRef.id,
            "userId" to userId,
            "title" to title.take(200).ifBlank { "New Chat" },
            "model" to model,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        docRef.set(data).await()
        Log.d(TAG, "Created conversation ${docRef.id} for user $userId")
        return docRef.id
    }

    /**
     * Updates conversation title and touches updatedAt.
     */
    suspend fun updateConversationTitle(conversationId: String, userId: String, title: String) {
        val docRef = db.collection("conversations").document(conversationId)
        docRef.update(
            mapOf(
                "title" to title.take(200),
                "updatedAt" to FieldValue.serverTimestamp()
            )
        ).await()
    }

    /**
     * Deletes a conversation and all its messages.
     */
    suspend fun deleteConversation(conversationId: String, userId: String) {
        try {
            val messagesSnapshot = db.collection("messages")
                .whereEqualTo("userId", userId)
                .whereEqualTo("conversationId", conversationId)
                .get()
                .await()

            for (doc in messagesSnapshot.documents) {
                doc.reference.delete().await()
            }

            db.collection("conversations").document(conversationId).delete().await()
            Log.d(TAG, "Deleted conversation $conversationId")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to delete conversation $conversationId", e)
            throw e
        }
    }

    /**
     * Appends a message to the conversation and updates the conversation's updatedAt timestamp.
     */
    suspend fun addMessage(
        userId: String,
        conversationId: String,
        sender: String,
        text: String,
        imageUrl: String? = null,
        thought: String? = null
    ): String {
        val docRef = db.collection("messages").document()
        val data = mutableMapOf<String, Any>(
            "id" to docRef.id,
            "conversationId" to conversationId,
            "userId" to userId,
            "sender" to sender,
            "text" to text,
            "createdAt" to FieldValue.serverTimestamp()
        )
        if (!imageUrl.isNullOrBlank()) {
            data["imageUrl"] = imageUrl
        }
        if (!thought.isNullOrBlank()) {
            data["thought"] = thought
        }

        docRef.set(data).await()

        // Touch the conversation's updatedAt timestamp
        try {
            db.collection("conversations").document(conversationId)
                .update("updatedAt", FieldValue.serverTimestamp())
                .await()
        } catch (e: Exception) {
            Log.w(TAG, "Could not update conversation timestamp", e)
        }

        return docRef.id
    }
}
