package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.SahayakCyan
import com.example.ui.theme.SahayakDarkCard
import com.example.ui.theme.SahayakDarkSurfaceVariant
import com.example.ui.theme.SahayakTeal

@Composable
fun EmptyChatGreeting(
    onPromptClick: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // App Orb Avatar
        Image(
            painter = painterResource(id = R.drawable.app_icon_sahayak_1793289095737),
            contentDescription = "Sahayak Orb",
            modifier = Modifier
                .size(68.dp)
                .clip(CircleShape)
                .border(2.dp, SahayakTeal.copy(alpha = 0.6f), CircleShape)
        )

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "सहायक में आपका स्वागत है",
            style = MaterialTheme.typography.titleLarge.copy(
                fontWeight = FontWeight.Bold,
                fontSize = 22.sp
            ),
            color = Color.White
        )

        Spacer(modifier = Modifier.height(4.dp))

        Text(
            text = "आज मैं आपकी क्या सहायता कर सकता हूँ?",
            style = MaterialTheme.typography.bodyMedium,
            color = Color.Gray,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(28.dp))

        // Suggestion prompt cards
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            PromptCard(
                icon = Icons.Default.Code,
                title = "Android App Code",
                subtitle = "Write a Jetpack Compose ViewModel and Coroutines flow",
                prompt = "Explain and write a complete Jetpack Compose ViewModel with StateFlow and Coroutines.",
                onClick = onPromptClick
            )
            PromptCard(
                icon = Icons.Default.Image,
                title = "Create an AI Image",
                subtitle = "Generate image: Cybernetic peacock in a neon palace",
                prompt = "/imagine A cybernetic peacock in a neon palace, ultra realistic, cinematic lighting",
                onClick = onPromptClick
            )
            PromptCard(
                icon = Icons.Default.Psychology,
                title = "Deep Reasoning & Math",
                subtitle = "Solve step-by-step calculus or quantum theory",
                prompt = "Explain quantum computing, qubits, and superposition with an intuitive real-world analogy.",
                onClick = onPromptClick
            )
            PromptCard(
                icon = Icons.Default.Language,
                title = "हिंदी में सहायता",
                subtitle = "एक सुंदर प्रेरक कहानी या निबंध लिखो",
                prompt = "सफलता और निरंतर प्रयास पर एक सुंदर और प्रेरक हिंदी कहानी लिखो।",
                onClick = onPromptClick
            )
        }
    }
}

@Composable
private fun PromptCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    prompt: String,
    onClick: (String) -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick(prompt) },
        color = SahayakDarkCard,
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2D333B))
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(SahayakDarkSurfaceVariant),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = SahayakCyan,
                    modifier = Modifier.size(18.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                    color = Color.White
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.Gray
                )
            }
        }
    }
}
