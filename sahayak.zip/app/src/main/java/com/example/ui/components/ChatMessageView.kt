package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.BitmapFactory
import android.util.Base64
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.R
import com.example.data.model.ChatMessage
import com.example.ui.theme.CodeBlockDark
import com.example.ui.theme.SahayakCyan
import com.example.ui.theme.SahayakTeal
import com.example.ui.theme.UserBubbleDark

@Composable
fun ChatMessageView(
    message: ChatMessage,
    isSpeaking: Boolean,
    onSpeakClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isUser = message.sender == "user"
    val context = LocalContext.current
    var isThinkingExpanded by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 6.dp),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
    ) {
        if (!isUser) {
            // Assistant Header
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(bottom = 6.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.app_icon_sahayak_1793289095737),
                    contentDescription = "Sahayak Avatar",
                    modifier = Modifier
                        .size(26.dp)
                        .clip(CircleShape)
                        .border(1.dp, SahayakTeal.copy(alpha = 0.5f), CircleShape)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Sahayak",
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    ),
                    color = SahayakTeal
                )
            }
        }

        // Deep Thinking accordion if present
        if (!isUser && !message.thought.isNullOrBlank()) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth(0.92f)
                    .padding(bottom = 8.dp)
                    .clickable { isThinkingExpanded = !isThinkingExpanded },
                shape = RoundedCornerShape(10.dp),
                color = Color(0xFF1B2028),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2C323D))
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Psychology,
                                contentDescription = null,
                                tint = SahayakCyan,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Thought for a few seconds",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Medium),
                                color = SahayakCyan
                            )
                        }
                        Icon(
                            imageVector = if (isThinkingExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                            contentDescription = null,
                            tint = Color.Gray,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    AnimatedVisibility(visible = isThinkingExpanded) {
                        Column(modifier = Modifier.padding(top = 8.dp)) {
                            Text(
                                text = message.thought,
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF9EABB9)
                            )
                        }
                    }
                }
            }
        }

        // Message Body
        Box(
            modifier = Modifier
                .widthIn(max = if (isUser) 320.dp else 400.dp)
                .clip(
                    RoundedCornerShape(
                        topStart = 16.dp,
                        topEnd = 16.dp,
                        bottomStart = if (isUser) 16.dp else 4.dp,
                        bottomEnd = if (isUser) 4.dp else 16.dp
                    )
                )
                .background(if (isUser) UserBubbleDark else Color(0xFF161B22))
                .border(
                    width = 1.dp,
                    color = if (isUser) Color(0xFF38404A) else Color(0xFF282E37),
                    shape = RoundedCornerShape(
                        topStart = 16.dp,
                        topEnd = 16.dp,
                        bottomStart = if (isUser) 16.dp else 4.dp,
                        bottomEnd = if (isUser) 4.dp else 16.dp
                    )
                )
                .padding(12.dp)
        ) {
            Column {
                // Attached / Generated Image display
                if (!message.imageUrl.isNullOrBlank()) {
                    MessageImageView(imageUrl = message.imageUrl)
                    Spacer(modifier = Modifier.height(8.dp))
                }

                // Render content with code block support
                FormattedMessageText(text = message.text, isUser = isUser)
            }
        }

        // Assistant Actions Toolbar
        if (!isUser) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Start,
                modifier = Modifier.padding(top = 4.dp)
            ) {
                // Speak button
                IconButton(
                    onClick = onSpeakClick,
                    modifier = Modifier
                        .size(32.dp)
                        .testTag("speak_button_${message.id}")
                ) {
                    Icon(
                        imageVector = if (isSpeaking) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                        contentDescription = "Read Aloud",
                        tint = if (isSpeaking) SahayakCyan else Color.Gray,
                        modifier = Modifier.size(17.dp)
                    )
                }

                Spacer(modifier = Modifier.width(2.dp))

                // Copy button
                IconButton(
                    onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        val clip = ClipData.newPlainText("Sahayak Response", message.text)
                        clipboard.setPrimaryClip(clip)
                        Toast.makeText(context, "Copied to clipboard", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ContentCopy,
                        contentDescription = "Copy message",
                        tint = Color.Gray,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun MessageImageView(imageUrl: String) {
    if (imageUrl.startsWith("data:image")) {
        // Base64 decoded image
        val base64Data = imageUrl.substringAfter(",")
        val imageBitmap = remember(base64Data) {
            try {
                val decodedBytes = Base64.decode(base64Data, Base64.DEFAULT)
                BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.size)?.asImageBitmap()
            } catch (e: Exception) {
                null
            }
        }

        if (imageBitmap != null) {
            Image(
                bitmap = imageBitmap,
                contentDescription = "Image content",
                modifier = Modifier
                    .fillMaxWidth()
                    .height(220.dp)
                    .clip(RoundedCornerShape(12.dp)),
                contentScale = ContentScale.Crop
            )
        }
    } else {
        // Network image URL
        AsyncImage(
            model = imageUrl,
            contentDescription = "Attached Image",
            modifier = Modifier
                .fillMaxWidth()
                .height(220.dp)
                .clip(RoundedCornerShape(12.dp)),
            contentScale = ContentScale.Crop
        )
    }
}

@Composable
private fun FormattedMessageText(text: String, isUser: Boolean) {
    val context = LocalContext.current

    // Parse code blocks delineated by ```
    val parts = remember(text) {
        splitIntoBlocks(text)
    }

    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        for (part in parts) {
            when (part) {
                is Block.Code -> {
                    // Code snippet block with copy button
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp)),
                        color = CodeBlockDark,
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2C313A))
                    ) {
                        Column {
                            // Header bar
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color(0xFF1E222A))
                                    .padding(horizontal = 10.dp, vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = part.language.ifBlank { "code" },
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color.LightGray
                                )
                                var copied by remember { mutableStateOf(false) }
                                Row(
                                    modifier = Modifier
                                        .clickable {
                                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                            val clip = ClipData.newPlainText("Code", part.code)
                                            clipboard.setPrimaryClip(clip)
                                            copied = true
                                            Toast.makeText(context, "Code copied!", Toast.LENGTH_SHORT).show()
                                        }
                                        .padding(2.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = if (copied) Icons.Default.Check else Icons.Default.ContentCopy,
                                        contentDescription = "Copy code",
                                        tint = if (copied) SahayakTeal else Color.Gray,
                                        modifier = Modifier.size(13.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = if (copied) "Copied" else "Copy",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (copied) SahayakTeal else Color.Gray
                                    )
                                }
                            }
                            // Code text
                            Text(
                                text = part.code,
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 12.sp,
                                    lineHeight = 16.sp
                                ),
                                color = Color(0xFFE2E8F0),
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    }
                }
                is Block.Text -> {
                    Text(
                        text = part.content,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            lineHeight = 22.sp,
                            fontSize = 15.sp
                        ),
                        color = if (isUser) Color.White else Color(0xFFECEFF4)
                    )
                }
            }
        }
    }
}

private sealed interface Block {
    data class Text(val content: String) : Block
    data class Code(val language: String, val code: String) : Block
}

private fun splitIntoBlocks(raw: String): List<Block> {
    val result = mutableListOf<Block>()
    val pattern = Regex("```([a-zA-Z]*)\\n([\\s\\S]*?)```")
    var lastIndex = 0

    for (match in pattern.findAll(raw)) {
        val range = match.range
        if (range.first > lastIndex) {
            val textBefore = raw.substring(lastIndex, range.first).trim()
            if (textBefore.isNotEmpty()) {
                result.add(Block.Text(textBefore))
            }
        }
        val lang = match.groupValues[1].trim()
        val code = match.groupValues[2].trimEnd()
        result.add(Block.Code(lang, code))
        lastIndex = range.last + 1
    }

    if (lastIndex < raw.length) {
        val remaining = raw.substring(lastIndex).trim()
        if (remaining.isNotEmpty()) {
            result.add(Block.Text(remaining))
        }
    }

    if (result.isEmpty() && raw.isNotBlank()) {
        result.add(Block.Text(raw))
    }

    return result
}
