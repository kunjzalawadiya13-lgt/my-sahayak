package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// ChatGPT inspired dark luxury palette
val SahayakDarkBg = Color(0xFF0F1117)
val SahayakDarkSurface = Color(0xFF161B22)
val SahayakDarkSurfaceVariant = Color(0xFF21262D)
val SahayakDarkCard = Color(0xFF1F242C)

val SahayakTeal = Color(0xFF10A37F)
val SahayakCyan = Color(0xFF38BDF8)
val SahayakPurple = Color(0xFF8B5CF6)

val TextPrimaryDark = Color(0xFFECEFF4)
val TextSecondaryDark = Color(0xFF9CA3AF)
val TextMutedDark = Color(0xFF6B7280)

val UserBubbleDark = Color(0xFF2D333B)
val AssistantBubbleDark = Color(0xFF161B22)

val BorderSubtleDark = Color(0xFF30363D)
val CodeBlockDark = Color(0xFF0D1117)

// Light theme equivalents
val SahayakLightBg = Color(0xFFF7F7F8)
val SahayakLightSurface = Color(0xFFFFFFFF)
val SahayakLightCard = Color(0xFFF0F2F5)
val TextPrimaryLight = Color(0xFF1F2328)
val TextSecondaryLight = Color(0xFF656D76)
val UserBubbleLight = Color(0xFFE5E7EB)
