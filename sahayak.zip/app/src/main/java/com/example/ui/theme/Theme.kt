package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = SahayakTeal,
    onPrimary = Color.White,
    primaryContainer = SahayakDarkSurfaceVariant,
    onPrimaryContainer = SahayakTeal,
    secondary = SahayakCyan,
    onSecondary = Color.Black,
    tertiary = SahayakPurple,
    background = SahayakDarkBg,
    onBackground = TextPrimaryDark,
    surface = SahayakDarkSurface,
    onSurface = TextPrimaryDark,
    surfaceVariant = SahayakDarkSurfaceVariant,
    onSurfaceVariant = TextSecondaryDark,
    outline = BorderSubtleDark
)

private val LightColorScheme = lightColorScheme(
    primary = SahayakTeal,
    onPrimary = Color.White,
    primaryContainer = SahayakLightCard,
    onPrimaryContainer = SahayakTeal,
    secondary = SahayakCyan,
    onSecondary = Color.White,
    tertiary = SahayakPurple,
    background = SahayakLightBg,
    onBackground = TextPrimaryLight,
    surface = SahayakLightSurface,
    onSurface = TextPrimaryLight,
    surfaceVariant = SahayakLightCard,
    onSurfaceVariant = TextSecondaryLight,
    outline = Color(0xFFD0D7DE)
)

@Composable
fun SahayakTheme(
    darkTheme: Boolean = true, // Default to gorgeous dark mode like ChatGPT
    dynamicColor: Boolean = false, // Preserve brand teal/dark aesthetic
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
