package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.ChatMessage
import com.example.ui.components.ChatDrawer
import com.example.ui.components.ChatInputBar
import com.example.ui.components.ChatMessageView
import com.example.ui.components.EmptyChatGreeting
import com.example.ui.components.LiveVoiceModal
import com.example.ui.theme.SahayakCyan
import com.example.ui.theme.SahayakDarkBg
import com.example.ui.theme.SahayakDarkCard
import com.example.ui.theme.SahayakDarkSurface
import com.example.ui.theme.SahayakDarkSurfaceVariant
import com.example.ui.theme.SahayakTeal
import com.example.ui.viewmodel.ChatViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainChatScreen(
    viewModel: ChatViewModel,
    modifier: Modifier = Modifier
) {
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    val conversations by viewModel.conversations.collectAsStateWithLifecycle()
    val activeConversationId by viewModel.activeConversationId.collectAsStateWithLifecycle()
    val messages by viewModel.messages.collectAsStateWithLifecycle()
    val selectedModel by viewModel.selectedModel.collectAsStateWithLifecycle()
    val inputText by viewModel.inputText.collectAsStateWithLifecycle()
    val attachedImage by viewModel.selectedImageBitmap.collectAsStateWithLifecycle()
    val isGenerating by viewModel.isGenerating.collectAsStateWithLifecycle()
    val streamingText by viewModel.streamingMessageText.collectAsStateWithLifecycle()
    val isLiveVoiceOpen by viewModel.isLiveVoiceOpen.collectAsStateWithLifecycle()
    val errorMessage by viewModel.errorMessage.collectAsStateWithLifecycle()

    val isSpeaking by viewModel.isSpeaking.collectAsStateWithLifecycle()
    val activeSpeakingId by viewModel.activeSpeakingId.collectAsStateWithLifecycle()

    var showModelMenu by remember { mutableStateOf(false) }
    var showMoreMenu by remember { mutableStateOf(false) }

    // Scroll to bottom on new message or streaming update
    LaunchedEffect(messages.size, streamingText.length) {
        if (messages.isNotEmpty() || streamingText.isNotEmpty()) {
            val targetIndex = (messages.size + if (streamingText.isNotEmpty()) 1 else 0) - 1
            if (targetIndex >= 0) {
                listState.animateScrollToItem(targetIndex)
            }
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = SahayakDarkSurface,
                modifier = Modifier.width(310.dp)
            ) {
                ChatDrawer(
                    conversations = conversations,
                    activeConversationId = activeConversationId,
                    onConversationSelect = { id ->
                        viewModel.selectConversation(id)
                        scope.launch { drawerState.close() }
                    },
                    onNewChatClick = {
                        viewModel.startNewConversation()
                        scope.launch { drawerState.close() }
                    },
                    onDeleteConversation = { id ->
                        viewModel.deleteConversationById(id)
                    },
                    onSignOutClick = {
                        Firebase.auth.signOut()
                    }
                )
            }
        }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        // Model Picker Pill
                        Box {
                            Surface(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(20.dp))
                                    .clickable { showModelMenu = true }
                                    .testTag("model_selector_button"),
                                color = SahayakDarkSurfaceVariant,
                                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF30363D))
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    val modelLabel = when (selectedModel) {
                                        "gemini-4-argon" -> "Sahayak 4 Argon"
                                        "gemini-3.5-flash-lite" -> "Sahayak Lite"
                                        "gemini-nano-banana-2.1" -> "Nano Banana (Image)"
                                        else -> "Sahayak 3.8 Flash"
                                    }
                                    Text(
                                        text = modelLabel,
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                                        color = Color.White
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Icon(
                                        imageVector = Icons.Default.KeyboardArrowDown,
                                        contentDescription = "Select Model",
                                        tint = SahayakCyan,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }

                            DropdownMenu(
                                expanded = showModelMenu,
                                onDismissRequest = { showModelMenu = false },
                                modifier = Modifier.background(SahayakDarkCard)
                            ) {
                                DropdownMenuItem(
                                    text = {
                                        Column {
                                            Text("Sahayak 3.8 Flash", fontWeight = FontWeight.Bold, color = Color.White)
                                            Text("Default smart & fast assistant", fontSize = 11.sp, color = Color.Gray)
                                        }
                                    },
                                    onClick = {
                                        viewModel.setSelectedModel("gemini-3.8-flash")
                                        showModelMenu = false
                                    }
                                )
                                DropdownMenuItem(
                                    text = {
                                        Column {
                                            Text("Sahayak 4 Argon (Reasoning)", fontWeight = FontWeight.Bold, color = SahayakCyan)
                                            Text("Deep thinking for math & coding", fontSize = 11.sp, color = Color.Gray)
                                        }
                                    },
                                    onClick = {
                                        viewModel.setSelectedModel("gemini-4-argon")
                                        showModelMenu = false
                                    }
                                )
                                DropdownMenuItem(
                                    text = {
                                        Column {
                                            Text("Sahayak Fast Lite", fontWeight = FontWeight.Bold, color = Color.White)
                                            Text("Ultra-low latency quick responses", fontSize = 11.sp, color = Color.Gray)
                                        }
                                    },
                                    onClick = {
                                        viewModel.setSelectedModel("gemini-3.5-flash-lite")
                                        showModelMenu = false
                                    }
                                )
                                DropdownMenuItem(
                                    text = {
                                        Column {
                                            Text("Nano Banana 2.1 (Image)", fontWeight = FontWeight.Bold, color = SahayakTeal)
                                            Text("High quality text-to-image synthesis", fontSize = 11.sp, color = Color.Gray)
                                        }
                                    },
                                    onClick = {
                                        viewModel.setSelectedModel("gemini-nano-banana-2.1")
                                        showModelMenu = false
                                    }
                                )
                            }
                        }
                    },
                    navigationIcon = {
                        IconButton(
                            onClick = { scope.launch { drawerState.open() } },
                            modifier = Modifier.testTag("menu_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Menu,
                                contentDescription = "Open Chat Menu",
                                tint = Color.White
                            )
                        }
                    },
                    actions = {
                        // New Chat Button
                        IconButton(onClick = { viewModel.startNewConversation() }) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = "New Chat",
                                tint = SahayakTeal
                            )
                        }

                        // More options
                        if (activeConversationId != null) {
                            Box {
                                IconButton(onClick = { showMoreMenu = true }) {
                                    Icon(
                                        imageVector = Icons.Default.MoreVert,
                                        contentDescription = "More Options",
                                        tint = Color.Gray
                                    )
                                }
                                DropdownMenu(
                                    expanded = showMoreMenu,
                                    onDismissRequest = { showMoreMenu = false },
                                    modifier = Modifier.background(SahayakDarkCard)
                                ) {
                                    DropdownMenuItem(
                                        leadingIcon = {
                                            Icon(
                                                imageVector = Icons.Default.Delete,
                                                contentDescription = null,
                                                tint = Color(0xFFEF4444)
                                            )
                                        },
                                        text = { Text("Delete Conversation", color = Color(0xFFEF4444)) },
                                        onClick = {
                                            viewModel.deleteCurrentConversation()
                                            showMoreMenu = false
                                        }
                                    )
                                }
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = SahayakDarkBg,
                        titleContentColor = Color.White
                    )
                )
            },
            bottomBar = {
                ChatInputBar(
                    text = inputText,
                    onTextChange = { viewModel.setInputText(it) },
                    attachedImage = attachedImage,
                    onAttachImage = { viewModel.attachImage(it) },
                    onRemoveImage = { viewModel.clearAttachedImage() },
                    isGenerating = isGenerating,
                    onSendClick = { viewModel.sendMessage() },
                    onStopClick = { viewModel.stopGeneration() },
                    onLiveVoiceClick = { viewModel.setLiveVoiceOpen(true) }
                )
            },
            containerColor = SahayakDarkBg
        ) { paddingValues ->
            Column(
                modifier = modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                // Error Banner
                AnimatedVisibility(visible = errorMessage != null) {
                    if (errorMessage != null) {
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 6.dp),
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFF3F1919),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFDC2626))
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = errorMessage!!,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFFFCA5A5),
                                    modifier = Modifier.weight(1f)
                                )
                                Text(
                                    text = "Dismiss",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    color = Color.White,
                                    modifier = Modifier
                                        .clickable { viewModel.dismissError() }
                                        .padding(start = 8.dp)
                                )
                            }
                        }
                    }
                }

                // Chat Messages Thread
                if (messages.isEmpty() && streamingText.isEmpty() && !isGenerating) {
                    EmptyChatGreeting(
                        onPromptClick = { prompt ->
                            viewModel.setInputText(prompt)
                            viewModel.sendMessage(prompt)
                        },
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                    )
                } else {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        contentPadding = PaddingValues(vertical = 12.dp)
                    ) {
                        items(messages, key = { it.id }) { msg ->
                            val isMsgSpeaking = isSpeaking && activeSpeakingId == msg.id
                            ChatMessageView(
                                message = msg,
                                isSpeaking = isMsgSpeaking,
                                onSpeakClick = {
                                    viewModel.speakMessage(msg.id, msg.text)
                                }
                            )
                        }

                        // Live Streaming Text bubble
                        if (streamingText.isNotEmpty()) {
                            item {
                                ChatMessageView(
                                    message = ChatMessage(
                                        id = "streaming_temp",
                                        sender = "model",
                                        text = streamingText
                                    ),
                                    isSpeaking = false,
                                    onSpeakClick = {}
                                )
                            }
                        } else if (isGenerating) {
                            item {
                                // Generating shimmer indicator
                                Row(
                                    modifier = Modifier
                                        .padding(horizontal = 16.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(18.dp),
                                        color = SahayakTeal,
                                        strokeWidth = 2.dp
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Text(
                                        text = if (selectedModel == "gemini-nano-banana-2.1") "Creating image..." else "Sahayak is thinking...",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color.Gray
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Live Voice Modal Overlay
        if (isLiveVoiceOpen) {
            val lastAssistantText = messages.lastOrNull { it.sender == "model" }?.text ?: streamingText
            LiveVoiceModal(
                isSpeaking = isSpeaking,
                isGenerating = isGenerating,
                lastResponseText = lastAssistantText,
                onUserSpoke = { spoken ->
                    viewModel.sendMessage(spoken)
                },
                onStopSpeaking = { viewModel.stopSpeaking() },
                onClose = { viewModel.setLiveVoiceOpen(false) }
            )
        }
    }
}
