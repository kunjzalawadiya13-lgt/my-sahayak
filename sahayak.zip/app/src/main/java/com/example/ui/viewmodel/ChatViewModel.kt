package com.example.ui.viewmodel

import android.graphics.Bitmap
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.GeminiAiService
import com.example.data.model.ChatMessage
import com.example.data.model.Conversation
import com.example.data.repository.ChatRepository
import com.example.voice.SpeechManager
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

private const val TAG = "ChatViewModel"

class ChatViewModel(
    private val repository: ChatRepository,
    private val speechManager: SpeechManager,
    val currentUserId: String
) : ViewModel() {

    private val aiService = GeminiAiService()

    val conversations: StateFlow<List<Conversation>> = repository.observeConversations(currentUserId)
        .catch { e ->
            Log.e(TAG, "Error observing conversations", e)
            _errorMessage.value = "Failed to load chats: ${e.localizedMessage}"
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = emptyList()
        )

    private val _activeConversationId = MutableStateFlow<String?>(null)
    val activeConversationId: StateFlow<String?> = _activeConversationId.asStateFlow()

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _selectedModel = MutableStateFlow("gemini-3.8-flash")
    val selectedModel: StateFlow<String> = _selectedModel.asStateFlow()

    private val _inputText = MutableStateFlow("")
    val inputText: StateFlow<String> = _inputText.asStateFlow()

    private val _selectedImageBitmap = MutableStateFlow<Bitmap?>(null)
    val selectedImageBitmap: StateFlow<Bitmap?> = _selectedImageBitmap.asStateFlow()

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    private val _streamingMessageText = MutableStateFlow("")
    val streamingMessageText: StateFlow<String> = _streamingMessageText.asStateFlow()

    private val _isLiveVoiceOpen = MutableStateFlow(false)
    val isLiveVoiceOpen: StateFlow<Boolean> = _isLiveVoiceOpen.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    val isSpeaking = speechManager.isSpeaking
    val activeSpeakingId = speechManager.activeMessageId

    private var messagesObservationJob: Job? = null
    private var generationJob: Job? = null

    init {
        // Auto-select most recent conversation if available
        viewModelScope.launch {
            conversations.collect { list ->
                if (_activeConversationId.value == null && list.isNotEmpty()) {
                    selectConversation(list.first().id)
                }
            }
        }
    }

    fun setInputText(text: String) {
        _inputText.value = text
    }

    fun setSelectedModel(modelName: String) {
        _selectedModel.value = modelName
    }

    fun attachImage(bitmap: Bitmap) {
        _selectedImageBitmap.value = bitmap
    }

    fun clearAttachedImage() {
        _selectedImageBitmap.value = null
    }

    fun setLiveVoiceOpen(open: Boolean) {
        _isLiveVoiceOpen.value = open
        if (!open) {
            speechManager.stop()
        }
    }

    fun selectConversation(conversationId: String) {
        if (_activeConversationId.value == conversationId) return
        _activeConversationId.value = conversationId
        _streamingMessageText.value = ""
        speechManager.stop()

        messagesObservationJob?.cancel()
        messagesObservationJob = viewModelScope.launch {
            repository.observeMessages(currentUserId, conversationId)
                .catch { e ->
                    Log.e(TAG, "Error observing messages for $conversationId", e)
                }
                .collect { messageList ->
                    _messages.value = messageList
                }
        }
    }

    fun startNewConversation() {
        _activeConversationId.value = null
        _messages.value = emptyList()
        _streamingMessageText.value = ""
        _selectedImageBitmap.value = null
        _inputText.value = ""
        speechManager.stop()
    }

    fun deleteCurrentConversation() {
        val convId = _activeConversationId.value ?: return
        viewModelScope.launch {
            try {
                repository.deleteConversation(convId, currentUserId)
                startNewConversation()
            } catch (e: Exception) {
                _errorMessage.value = "Failed to delete conversation: ${e.localizedMessage}"
            }
        }
    }

    fun deleteConversationById(conversationId: String) {
        viewModelScope.launch {
            try {
                repository.deleteConversation(conversationId, currentUserId)
                if (_activeConversationId.value == conversationId) {
                    startNewConversation()
                }
            } catch (e: Exception) {
                _errorMessage.value = "Failed to delete: ${e.localizedMessage}"
            }
        }
    }

    fun sendMessage(userText: String = _inputText.value) {
        val trimmed = userText.trim()
        val attachedBitmap = _selectedImageBitmap.value
        if (trimmed.isEmpty() && attachedBitmap == null) return
        if (_isGenerating.value) return

        _inputText.value = ""
        _selectedImageBitmap.value = null
        _isGenerating.value = true
        _streamingMessageText.value = ""
        speechManager.stop()

        generationJob = viewModelScope.launch {
            try {
                // Ensure active conversation
                var convId = _activeConversationId.value
                if (convId == null) {
                    val title = if (trimmed.isNotBlank()) {
                        trimmed.take(40)
                    } else "Image Request"
                    convId = repository.createConversation(currentUserId, title, _selectedModel.value)
                    selectConversation(convId)
                }

                // Convert attached image to base64 if present
                val userImageBase64 = attachedBitmap?.let { aiService.bitmapToBase64(it) }

                // Add user message to Firestore
                repository.addMessage(
                    userId = currentUserId,
                    conversationId = convId,
                    sender = "user",
                    text = trimmed,
                    imageUrl = userImageBase64
                )

                // Check if user is requesting Image Generation
                val isImageGen = _selectedModel.value == "gemini-nano-banana-2.1" ||
                        trimmed.startsWith("/imagine", ignoreCase = true) ||
                        trimmed.startsWith("create image", ignoreCase = true) ||
                        trimmed.startsWith("generate image", ignoreCase = true) ||
                        trimmed.startsWith("चित्र बनाओ", ignoreCase = true)

                if (isImageGen) {
                    val prompt = trimmed.removePrefix("/imagine").trim()
                        .ifBlank { "A stunning futuristic artwork" }
                    val generatedBitmap = aiService.generateImage(prompt)
                    if (generatedBitmap != null) {
                        val genBase64 = aiService.bitmapToBase64(generatedBitmap)
                        repository.addMessage(
                            userId = currentUserId,
                            conversationId = convId,
                            sender = "model",
                            text = "यहाँ आपकी बनाई गई इमेज है: \"$prompt\"",
                            imageUrl = genBase64
                        )
                    } else {
                        repository.addMessage(
                            userId = currentUserId,
                            conversationId = convId,
                            sender = "model",
                            text = "माफ़ कीजिये, इस समय इमेज जनरेट नहीं हो पाई। कृपया दोबारा प्रयास करें।"
                        )
                    }
                } else {
                    // Chat response generation with streaming
                    val currentHistory = _messages.value.map { it.sender to it.text }
                    val fullResponse = StringBuilder()

                    aiService.streamChatResponse(
                        prompt = trimmed,
                        history = currentHistory,
                        inputImage = attachedBitmap,
                        modelName = _selectedModel.value
                    ).collect { chunk ->
                        fullResponse.append(chunk)
                        _streamingMessageText.value = fullResponse.toString()
                    }

                    val finalOutput = fullResponse.toString().trim()
                    if (finalOutput.isNotEmpty()) {
                        val msgId = repository.addMessage(
                            userId = currentUserId,
                            conversationId = convId,
                            sender = "model",
                            text = finalOutput
                        )
                        // Auto-speak if in live voice mode
                        if (_isLiveVoiceOpen.value) {
                            speechManager.speak(finalOutput, msgId)
                        }
                    }
                }
            } catch (e: CancellationException) {
                Log.d(TAG, "Generation cancelled by user")
            } catch (e: Exception) {
                Log.e(TAG, "Error generating response", e)
                _errorMessage.value = "Sahayak response error: ${e.localizedMessage}"
            } finally {
                _isGenerating.value = false
                _streamingMessageText.value = ""
            }
        }
    }

    fun stopGeneration() {
        generationJob?.cancel()
        _isGenerating.value = false
        _streamingMessageText.value = ""
    }

    fun speakMessage(messageId: String, text: String) {
        speechManager.speak(text, messageId)
    }

    fun stopSpeaking() {
        speechManager.stop()
    }

    fun dismissError() {
        _errorMessage.value = null
    }

    override fun onCleared() {
        super.onCleared()
        speechManager.shutdown()
        generationJob?.cancel()
        messagesObservationJob?.cancel()
    }
}
