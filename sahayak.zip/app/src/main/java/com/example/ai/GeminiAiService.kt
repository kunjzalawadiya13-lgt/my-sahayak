package com.example.ai

import android.graphics.Bitmap
import android.util.Base64
import android.util.Log
import com.google.firebase.Firebase
import com.google.firebase.ai.ImagePart
import com.google.firebase.ai.ResponseModality
import com.google.firebase.ai.ai
import com.google.firebase.ai.content
import com.google.firebase.ai.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withTimeout
import java.io.ByteArrayOutputStream

private const val TAG = "GeminiAiService"

data class GenerationResult(
    val text: String,
    val thought: String? = null,
    val generatedBitmap: Bitmap? = null
)

class GeminiAiService {

    private val defaultSystemInstruction = content {
        text(
            "You are Sahayak (सहायक), an exceptionally capable, intelligent, and empathetic AI assistant. " +
            "You provide comprehensive, accurate, and structured answers in Hindi, English, Hinglish, or any language the user prefers. " +
            "Use clear markdown with bold headers, code snippets with syntax highlighting, bullet points, and step-by-step reasoning when solving complex queries. " +
            "Be encouraging, concise when needed, and detailed when asked."
        )
    }

    private fun getGenerativeModel(modelName: String, enableThinking: Boolean = false) = Firebase.ai.generativeModel(
        modelName = modelName,
        systemInstruction = defaultSystemInstruction
    )

    private val imageGenModel by lazy {
        val config = generationConfig {
            responseModalities = listOf(ResponseModality.IMAGE)
        }
        Firebase.ai.generativeModel(
            modelName = "gemini-nano-banana-2.1",
            generationConfig = config
        )
    }

    /**
     * Streams text chunks from Gemini model for low TTFT (Time to First Token).
     */
    fun streamChatResponse(
        prompt: String,
        history: List<Pair<String, String>>, // sender ("user" or "model"), text
        inputImage: Bitmap? = null,
        modelName: String = "gemini-3.8-flash"
    ): Flow<String> = flow {
        val model = getGenerativeModel(modelName)

        val contentsList = mutableListOf<com.google.firebase.ai.Content>()
        for ((sender, messageText) in history) {
            val role = if (sender == "user") "user" else "model"
            contentsList.add(content(role) { text(messageText) })
        }

        // Add current prompt
        contentsList.add(content("user") {
            inputImage?.let { image(it) }
            text(prompt)
        })

        withTimeout(60_000L) {
            val responseStream = model.generateContentStream(*contentsList.toTypedArray())
            responseStream.collect { chunk ->
                val chunkText = chunk.text.orEmpty()
                if (chunkText.isNotEmpty()) {
                    emit(chunkText)
                }
            }
        }
    }

    /**
     * Generates an image using gemini-nano-banana-2.1.
     */
    suspend fun generateImage(prompt: String): Bitmap? {
        return try {
            withTimeout(60_000L) {
                val response = imageGenModel.generateContent(prompt)
                val imagePart = response.candidates.firstOrNull()
                    ?.content?.parts?.filterIsInstance<ImagePart>()
                    ?.firstOrNull()
                imagePart?.image
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Image generation error", e)
            throw e
        }
    }

    /**
     * Converts a Bitmap to a compressed Base64 data URL string for saving into Firestore or displaying.
     */
    fun bitmapToBase64(bitmap: Bitmap): String {
        val outputStream = ByteArrayOutputStream()
        // Resize bitmap if very large to keep Firestore document well under 1MB limit
        val maxDimension = 512
        val scaled = if (bitmap.width > maxDimension || bitmap.height > maxDimension) {
            val ratio = bitmap.width.toFloat() / bitmap.height.toFloat()
            val (width, height) = if (ratio > 1f) {
                maxDimension to (maxDimension / ratio).toInt()
            } else {
                (maxDimension * ratio).toInt() to maxDimension
            }
            Bitmap.createScaledBitmap(bitmap, width, height, true)
        } else {
            bitmap
        }
        scaled.compress(Bitmap.CompressFormat.JPEG, 75, outputStream)
        val bytes = outputStream.toByteArray()
        return "data:image/jpeg;base64," + Base64.encodeToString(bytes, Base64.NO_WRAP)
    }
}
